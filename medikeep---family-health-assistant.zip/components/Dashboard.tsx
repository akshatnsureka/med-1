import React, { useState } from 'react';
import { Medicine, User, DoseLog } from '../types';
import { Icons } from './Icons';

interface DashboardProps {
  medicines: Medicine[];
  users: User[];
  onLogDose: (medId: string, status: 'taken' | 'skipped') => void;
  doseLogs: DoseLog[];
}

export const Dashboard: React.FC<DashboardProps> = ({ medicines, users, onLogDose, doseLogs }) => {
  const [selectedUserId, setSelectedUserId] = useState<string | 'all'>('all');
  
  const getTodayLogs = (medId: string) => {
    const today = new Date().toDateString();
    return doseLogs.filter(log => 
      log.medicineId === medId && 
      new Date(log.timestamp).toDateString() === today
    );
  };

  const isTakenToday = (med: Medicine) => {
    const logs = getTodayLogs(med.id);
    return logs.some(l => l.status === 'taken');
  };

  // Filter medicines based on user selection
  const visibleMedicines = selectedUserId === 'all' 
    ? medicines 
    : medicines.filter(m => m.userId === selectedUserId);

  const dueMedicines = visibleMedicines.filter(med => !isTakenToday(med));
  const takenMedicines = visibleMedicines.filter(med => isTakenToday(med));

  // Low stock warnings (global or user specific)
  const lowStockMeds = visibleMedicines.filter(m => m.currentStock <= m.lowStockThreshold);

  // Get User Name for greeting
  const currentUser = users.find(u => u.id === selectedUserId);
  const greetingName = currentUser ? currentUser.name : 'Family';

  return (
    <div className="p-4 pb-24 space-y-6">
      <header className="pt-2">
        <div className="flex justify-between items-start mb-4">
           <div>
            <h1 className="text-2xl font-bold text-gray-900">Hi, {greetingName}</h1>
            <p className="text-gray-500 text-sm">
              {dueMedicines.length > 0 
                ? `You have ${dueMedicines.length} meds due today` 
                : "You're all caught up!"}
            </p>
          </div>
          {/* Add Profile Shortcut */}
          <a href="#/settings" className="bg-blue-50 p-2 rounded-full text-blue-600">
             <Icons.Settings className="w-5 h-5" />
          </a>
        </div>

        {/* User Filter Bar */}
        <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
          <button 
            onClick={() => setSelectedUserId('all')}
            className={`flex flex-col items-center gap-1 min-w-[60px] transition-opacity ${selectedUserId === 'all' ? 'opacity-100' : 'opacity-50'}`}
          >
            <div className={`w-14 h-14 rounded-full bg-gray-800 flex items-center justify-center text-white shadow-md ${selectedUserId === 'all' ? 'ring-2 ring-offset-2 ring-gray-800' : ''}`}>
              <Icons.Users className="w-6 h-6" />
            </div>
            <span className="text-xs font-medium text-gray-700">All</span>
          </button>

          {users.map(u => (
            <button 
              key={u.id}
              onClick={() => setSelectedUserId(u.id)}
              className={`flex flex-col items-center gap-1 min-w-[60px] transition-opacity ${selectedUserId === u.id ? 'opacity-100' : 'opacity-50'}`}
            >
              <div className={`w-14 h-14 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-md ${u.avatarColor} ${selectedUserId === u.id ? `ring-2 ring-offset-2 ring-gray-400` : ''}`}>
                {u.name[0]}
              </div>
              <span className="text-xs font-medium text-gray-700 truncate w-full text-center">{u.name}</span>
            </button>
          ))}
        </div>
      </header>

      {/* Alerts */}
      {lowStockMeds.length > 0 && (
        <div className="bg-orange-50 border border-orange-100 p-4 rounded-xl flex items-start gap-3 shadow-sm">
          <Icons.AlertCircle className="text-orange-500 w-5 h-5 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-orange-800 font-bold text-sm">Restock Needed</h4>
            <ul className="mt-1 space-y-1">
              {lowStockMeds.map(m => (
                <li key={m.id} className="text-orange-700 text-xs flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-orange-400 rounded-full"></span>
                  {m.name} ({m.currentStock} left)
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Today's Schedule */}
      <section>
        <h2 className="text-lg font-bold text-gray-800 mb-3 flex items-center gap-2">
          <Icons.Calendar className="w-5 h-5 text-blue-600" />
          Due Today
        </h2>
        <div className="space-y-3">
          {dueMedicines.length === 0 && (
            <div className="p-8 bg-white rounded-xl text-center border border-dashed border-gray-200">
              <Icons.CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-2" />
              <p className="text-gray-500">All clear! No medicines due.</p>
            </div>
          )}
          
          {dueMedicines.map(med => {
            const owner = users.find(u => u.id === med.userId);
            return (
              <div key={med.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <div className={`w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 shrink-0`}>
                     <Icons.Pill className="w-6 h-6" />
                   </div>
                   <div>
                     <h3 className="font-bold text-gray-800">{med.name}</h3>
                     <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                        <span className={`w-2 h-2 rounded-full ${owner?.avatarColor || 'bg-gray-400'}`}></span>
                        {owner?.name} • {med.frequency}
                     </div>
                   </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => onLogDose(med.id, 'skipped')}
                    className="p-2 rounded-full bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-500 transition"
                  >
                    <Icons.XCircle className="w-6 h-6" />
                  </button>
                  <button 
                    onClick={() => onLogDose(med.id, 'taken')}
                    className="p-2 rounded-full bg-blue-600 text-white shadow-lg shadow-blue-200 active:scale-95 transition"
                  >
                    <Icons.CheckCircle className="w-6 h-6" />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {/* Completed */}
      {takenMedicines.length > 0 && (
        <section>
          <h2 className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Completed</h2>
           <div className="space-y-2">
            {takenMedicines.map(med => {
               const owner = users.find(u => u.id === med.userId);
               return (
                <div key={med.id} className="bg-gray-50 p-3 rounded-lg flex items-center justify-between opacity-75">
                   <div className="flex items-center gap-3">
                     <div className={`w-2 h-8 rounded-full ${owner?.avatarColor || 'bg-gray-400'}`}></div>
                     <span className="font-medium text-gray-600 line-through decoration-gray-400">{med.name}</span>
                   </div>
                   <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Taken</span>
                </div>
               )
            })}
           </div>
        </section>
      )}
    </div>
  );
};