import React, { useState, useRef, useEffect } from 'react';
import { Medicine, User, Frequency } from '../types';
import { Icons } from './Icons';
import { parsePrescription } from '../services/geminiService';

interface InventoryProps {
  medicines: Medicine[];
  users: User[];
  onAddMedicine: (med: Medicine) => void;
  onDeleteMedicine: (id: string) => void;
}

export const Inventory: React.FC<InventoryProps> = ({ medicines, users, onAddMedicine, onDeleteMedicine }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [filterUser, setFilterUser] = useState<string | 'all'>('all');
  
  // Form State
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [stock, setStock] = useState(30);
  const [threshold, setThreshold] = useState(5);
  const [expiry, setExpiry] = useState('');
  const [rate, setRate] = useState(0);
  const [freq, setFreq] = useState<Frequency>(Frequency.DAILY);
  const [userId, setUserId] = useState(users[0]?.id || '');
  const [prescriptionImg, setPrescriptionImg] = useState<string | undefined>(undefined);

  // Effect to set default user when opening add form based on filter
  useEffect(() => {
    if (filterUser !== 'all') {
      setUserId(filterUser);
    } else if (users.length > 0) {
      setUserId(users[0].id);
    }
  }, [isAdding, filterUser, users]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsProcessing(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = reader.result as string;
        setPrescriptionImg(base64);
        
        const rawBase64 = base64.split(',')[1];
        const aiData = await parsePrescription(rawBase64);
        
        if (aiData) {
          if (aiData.medicineName) setName(aiData.medicineName);
          if (aiData.description) setDesc(aiData.description);
          if (aiData.suggestedStock) setStock(aiData.suggestedStock);
        }
        setIsProcessing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newMed: Medicine = {
      id: Date.now().toString(),
      name,
      description: desc,
      currentStock: Number(stock),
      totalStock: Number(stock),
      lowStockThreshold: Number(threshold),
      expiryDate: expiry,
      rate: Number(rate),
      frequency: freq,
      userId,
      prescriptionImage: prescriptionImg
    };
    onAddMedicine(newMed);
    setIsAdding(false);
    // Reset form
    setName(''); setDesc(''); setStock(30); setExpiry(''); setPrescriptionImg(undefined);
  };

  const displayedMedicines = filterUser === 'all' 
    ? medicines 
    : medicines.filter(m => m.userId === filterUser);

  if (isAdding) {
    return (
      <div className="p-4 bg-white min-h-full pb-24">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Add Medicine</h2>
          <button onClick={() => setIsAdding(false)} className="text-gray-500">Cancel</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* AI Camera Button */}
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-blue-300 rounded-xl p-6 flex flex-col items-center justify-center bg-blue-50 cursor-pointer active:bg-blue-100 transition"
          >
            {isProcessing ? (
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            ) : prescriptionImg ? (
              <img src={prescriptionImg} alt="Prescription" className="h-32 object-contain" />
            ) : (
              <>
                <Icons.Camera className="w-8 h-8 text-blue-500 mb-2" />
                <span className="text-sm text-blue-600 font-medium">Scan Prescription (Auto-Fill)</span>
              </>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*" 
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Medicine Name</label>
            <input required value={name} onChange={(e) => setName(e.target.value)} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. Amoxicillin" />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">For Whom?</label>
            <select value={userId} onChange={(e) => setUserId(e.target.value)} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none">
              {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Current Stock</label>
              <input type="number" required value={stock} onChange={(e) => setStock(Number(e.target.value))} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Low Alert At</label>
              <input type="number" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div>
              <label className="block text-sm font-medium text-gray-700">Cost per unit</label>
              <input type="number" step="0.01" value={rate} onChange={(e) => setRate(Number(e.target.value))} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Expiry Date</label>
              <input type="date" required value={expiry} onChange={(e) => setExpiry(e.target.value)} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Frequency</label>
            <select value={freq} onChange={(e) => setFreq(e.target.value as Frequency)} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none">
              {Object.values(Frequency).map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>

          <div>
             <label className="block text-sm font-medium text-gray-700">Description/Notes</label>
             <textarea value={desc} onChange={(e) => setDesc(e.target.value)} className="mt-1 w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none" rows={3}></textarea>
          </div>

          <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 hover:bg-blue-700 transition">
            Save Medicine
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Inventory</h1>
          <p className="text-xs text-gray-500">{displayedMedicines.length} items found</p>
        </div>
        <button onClick={() => setIsAdding(true)} className="bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition">
          <Icons.Plus className="w-6 h-6" />
        </button>
      </div>

      {/* User Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar mb-2">
        <button
          onClick={() => setFilterUser('all')}
          className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition ${filterUser === 'all' ? 'bg-gray-800 text-white' : 'bg-gray-200 text-gray-600'}`}
        >
          All Family
        </button>
        {users.map(u => (
          <button
            key={u.id}
            onClick={() => setFilterUser(u.id)}
            className={`px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition flex items-center gap-2 ${filterUser === u.id ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'}`}
          >
            <div className={`w-2 h-2 rounded-full ${u.avatarColor}`}></div>
            {u.name}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {displayedMedicines.length === 0 && (
          <div className="text-center py-10 text-gray-400">
            <Icons.Pill className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p>No medicines found for this filter.</p>
          </div>
        )}
        {displayedMedicines.map(med => {
           const isLow = med.currentStock <= med.lowStockThreshold;
           const isExpired = new Date(med.expiryDate) < new Date();
           const owner = users.find(u => u.id === med.userId);

           return (
            <div key={med.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${owner?.avatarColor || 'bg-gray-400'}`}>
                    {owner?.name[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">{med.name}</h3>
                    <p className="text-xs text-gray-500">{med.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${isLow ? 'bg-red-100 text-red-700 font-bold' : 'bg-green-100 text-green-700'}`}>
                        {med.currentStock} left
                      </span>
                      {isExpired && <span className="text-xs px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 font-bold">Expired</span>}
                    </div>
                  </div>
                </div>
                <button onClick={() => onDeleteMedicine(med.id)} className="text-gray-300 hover:text-red-500">
                  <Icons.Trash2 className="w-5 h-5" />
                </button>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-50 flex justify-between text-sm text-gray-500">
                <span>Exp: {med.expiryDate}</span>
                <span>{med.frequency}</span>
              </div>
              
              {med.prescriptionImage && (
                 <div className="mt-3">
                    <p className="text-xs font-semibold text-blue-600 mb-1 flex items-center gap-1">
                      <Icons.CheckCircle className="w-3 h-3" /> Rx Image Stored
                    </p>
                    <img src={med.prescriptionImage} alt="rx" className="h-16 rounded-md border object-cover" />
                 </div>
              )}
            </div>
           );
        })}
      </div>
    </div>
  );
};