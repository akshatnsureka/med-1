import React from 'react';
import { 
  Home, 
  Pill, 
  Activity, 
  Settings, 
  Plus, 
  Camera, 
  AlertCircle, 
  CheckCircle, 
  XCircle, 
  Calendar,
  Trash2,
  ChevronRight,
  Users,
  TrendingUp
} from 'lucide-react';

export const Icons = {
  Home, 
  Pill, 
  Activity, 
  Settings, 
  Plus, 
  Camera, 
  AlertCircle, 
  CheckCircle, 
  XCircle, 
  Calendar,
  Trash2,
  ChevronRight,
  Users,
  TrendingUp
};