import React, { useState } from 'react';
import { User } from '../types';
import { Icons } from './Icons';

interface SettingsProps {
  users: User[];
  onAddUser: (name: string, color: string) => void;
  onDeleteUser: (id: string) => void;
}

export const Settings: React.FC<SettingsProps> = ({ users, onAddUser, onDeleteUser }) => {
  const [newName, setNewName] = useState('');
  const [selectedColor, setSelectedColor] = useState('bg-blue-500');
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  const colors = [
    'bg-blue-500', 'bg-red-500', 'bg-green-500', 'bg-yellow-500', 
    'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500'
  ];

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      onAddUser(newName, selectedColor);
      setNewName('');
    }
  };

  const requestNotifications = () => {
    if ("Notification" in window) {
      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          setNotificationsEnabled(true);
          new Notification("MediKeep", { body: "Reminders enabled for your family!" });
        }
      });
    }
  };

  return (
    <div className="p-4 pb-24">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Family Settings</h1>
      
      {/* Add User Section */}
      <div className="bg-white p-4 rounded-xl shadow-sm mb-6">
        <h2 className="font-bold text-gray-700 mb-4">Add Family Member</h2>
        <form onSubmit={handleAdd}>
          <div className="mb-4">
            <label className="block text-xs font-medium text-gray-500 mb-1">Name</label>
            <input 
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="w-full p-3 bg-gray-50 rounded-lg border-none focus:ring-2 focus:ring-blue-100 outline-none"
              placeholder="e.g., Grandma"
            />
          </div>
          <div className="mb-4">
            <label className="block text-xs font-medium text-gray-500 mb-2">Avatar Color</label>
            <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
              {colors.map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setSelectedColor(c)}
                  className={`w-8 h-8 rounded-full flex-shrink-0 ${c} ${selectedColor === c ? 'ring-4 ring-offset-2 ring-gray-200' : ''}`}
                />
              ))}
            </div>
          </div>
          <button 
            type="submit"
            disabled={!newName}
            className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold disabled:opacity-50"
          >
            Add Profile
          </button>
        </form>
      </div>

      {/* Notification Settings */}
      <div className="bg-white p-4 rounded-xl shadow-sm mb-6 flex items-center justify-between">
        <div>
          <h2 className="font-bold text-gray-700">Notifications</h2>
          <p className="text-xs text-gray-500">Get daily reminders for meds</p>
        </div>
        <button 
          onClick={requestNotifications}
          className={`w-12 h-6 rounded-full transition-colors duration-200 flex items-center px-1 ${notificationsEnabled ? 'bg-green-500' : 'bg-gray-300'}`}
        >
          <div className={`w-4 h-4 bg-white rounded-full transition-transform duration-200 ${notificationsEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
        </button>
      </div>

      {/* Manage Users Section */}
      <div className="space-y-3">
        <h2 className="font-bold text-gray-700">Manage Profiles</h2>
        {users.map(user => (
          <div key={user.id} className="flex items-center justify-between bg-white p-3 rounded-lg border border-gray-100">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${user.avatarColor}`}>
                {user.name[0]}
              </div>
              <span className="font-medium text-gray-800">{user.name}</span>
            </div>
            {users.length > 1 && (
              <button 
                onClick={() => onDeleteUser(user.id)}
                className="p-2 text-gray-300 hover:text-red-500"
              >
                <Icons.Trash2 className="w-5 h-5" />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};