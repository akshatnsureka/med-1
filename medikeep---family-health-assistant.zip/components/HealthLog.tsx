import React, { useState } from 'react';
import { SymptomLog, Medicine, DoseLog, User } from '../types';
import { Icons } from './Icons';
import { analyzeSymptoms } from '../services/geminiService';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface HealthLogProps {
  logs: SymptomLog[];
  doseLogs: DoseLog[];
  medicines: Medicine[];
  users: User[];
  onAddLog: (log: SymptomLog) => void;
}

export const HealthLog: React.FC<HealthLogProps> = ({ logs, doseLogs, medicines, users, onAddLog }) => {
  const [activeTab, setActiveTab] = useState<'symptoms' | 'adherence'>('symptoms');
  const [symptomText, setSymptomText] = useState('');
  const [severity, setSeverity] = useState(5);
  const [aiResult, setAiResult] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  
  // Default to first user
  const [selectedUserId, setSelectedUserId] = useState(users[0]?.id || '');
  
  // Filter for history view
  const [filterUserId, setFilterUserId] = useState<string | 'all'>('all');

  const handleAnalyze = async () => {
    if (!symptomText) return;
    setLoadingAi(true);
    // Only analyze against medicines for the selected user
    const activeMeds = medicines
      .filter(m => m.userId === selectedUserId)
      .map(m => m.name);
      
    const result = await analyzeSymptoms(symptomText, activeMeds);
    setAiResult(result);
    setLoadingAi(false);
  };

  const handleSaveLog = () => {
    if (!symptomText) return;
    onAddLog({
      id: Date.now().toString(),
      userId: selectedUserId,
      timestamp: new Date().toISOString(),
      description: symptomText,
      severity: severity,
      aiAnalysis: aiResult || undefined
    });
    setSymptomText('');
    setAiResult(null);
    setSeverity(5);
  };

  const visibleLogs = filterUserId === 'all' 
    ? logs 
    : logs.filter(l => l.userId === filterUserId);

  // Prepare data for adherence chart (grouped by user or all?)
  // Let's show adherence for medicines belonging to the filtered view
  const adherenceMeds = filterUserId === 'all' ? medicines : medicines.filter(m => m.userId === filterUserId);
  
  const adherenceData = adherenceMeds.map(med => {
    const totalDoses = doseLogs.filter(l => l.medicineId === med.id).length;
    const takenDoses = doseLogs.filter(l => l.medicineId === med.id && l.status === 'taken').length;
    return {
      name: med.name,
      rate: totalDoses === 0 ? 0 : Math.round((takenDoses / totalDoses) * 100)
    };
  });

  return (
    <div className="p-4 pb-24">
      <div className="flex space-x-2 mb-6 bg-gray-200 p-1 rounded-lg">
        <button 
          onClick={() => setActiveTab('symptoms')}
          className={`flex-1 py-2 rounded-md text-sm font-medium transition ${activeTab === 'symptoms' ? 'bg-white shadow text-blue-600' : 'text-gray-600'}`}
        >
          Symptoms
        </button>
        <button 
          onClick={() => setActiveTab('adherence')}
          className={`flex-1 py-2 rounded-md text-sm font-medium transition ${activeTab === 'adherence' ? 'bg-white shadow text-blue-600' : 'text-gray-600'}`}
        >
          Adherence
        </button>
      </div>
      
      {/* Filter Bar for History/Charts */}
      <div className="mb-4 flex items-center gap-2 overflow-x-auto no-scrollbar">
         <span className="text-xs font-bold text-gray-500 uppercase">View:</span>
         <button 
            onClick={() => setFilterUserId('all')}
            className={`px-3 py-1 rounded-full text-xs ${filterUserId === 'all' ? 'bg-gray-800 text-white' : 'bg-white text-gray-600 border'}`}
         >
           All
         </button>
         {users.map(u => (
           <button 
             key={u.id}
             onClick={() => setFilterUserId(u.id)}
             className={`px-3 py-1 rounded-full text-xs flex items-center gap-1 ${filterUserId === u.id ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border'}`}
           >
             <div className={`w-2 h-2 rounded-full ${u.avatarColor}`}></div>
             {u.name}
           </button>
         ))}
      </div>

      {activeTab === 'symptoms' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-xl shadow-sm">
            <div className="flex justify-between items-center mb-3">
                <h3 className="font-bold text-gray-800">Log New Symptom</h3>
                <select 
                    value={selectedUserId} 
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    className="text-sm border border-gray-200 rounded-md p-1 outline-none"
                >
                    {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
            </div>
            
            <textarea
              value={symptomText}
              onChange={(e) => setSymptomText(e.target.value)}
              placeholder="Describe what you're feeling..."
              className="w-full p-3 bg-gray-50 rounded-lg border-none focus:ring-2 focus:ring-blue-100 outline-none"
              rows={3}
            />
            <div className="mt-4 flex items-center gap-4">
              <span className="text-sm text-gray-500">Severity: {severity}</span>
              <input 
                type="range" 
                min="1" max="10" 
                value={severity} 
                onChange={(e) => setSeverity(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>
            <div className="flex gap-2 mt-4">
              <button 
                onClick={handleAnalyze}
                disabled={loadingAi || !symptomText}
                className="flex-1 bg-purple-100 text-purple-700 py-2 rounded-lg font-medium flex items-center justify-center gap-2 disabled:opacity-50"
              >
                 {loadingAi ? 'Thinking...' : <><Icons.Activity className="w-4 h-4" /> AI Check</>}
              </button>
              <button 
                onClick={handleSaveLog}
                disabled={!symptomText}
                className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium disabled:opacity-50"
              >
                Save Log
              </button>
            </div>
            
            {aiResult && (
              <div className="mt-4 p-3 bg-purple-50 border border-purple-100 rounded-lg text-sm text-purple-800">
                <strong>AI Insight for {users.find(u => u.id === selectedUserId)?.name}:</strong> {aiResult}
              </div>
            )}
          </div>

          <div className="space-y-3">
            <h3 className="font-bold text-gray-700">History</h3>
            {visibleLogs.length === 0 && <p className="text-gray-400 text-sm">No symptoms logged for this selection.</p>}
            {visibleLogs.slice().reverse().map(log => {
               const user = users.find(u => u.id === log.userId);
               return (
                <div key={log.id} className="bg-white p-3 rounded-lg border border-gray-100">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2 mb-1">
                       <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] text-white font-bold ${user?.avatarColor || 'bg-gray-400'}`}>
                         {user?.name[0]}
                       </div>
                       <span className="text-xs text-gray-400">{new Date(log.timestamp).toLocaleDateString()}</span>
                    </div>
                    <span className="text-xs font-bold bg-red-100 text-red-600 px-2 rounded-full">Level {log.severity}</span>
                  </div>
                  <p className="text-gray-800 mt-1 text-sm">{log.description}</p>
                  {log.aiAnalysis && (
                    <p className="text-xs text-purple-600 mt-2 bg-purple-50 p-2 rounded">🤖 {log.aiAnalysis}</p>
                  )}
                </div>
               )
            })}
          </div>
        </div>
      )}

      {activeTab === 'adherence' && (
        <div className="bg-white p-4 rounded-xl shadow-sm h-96">
          <h3 className="font-bold text-gray-800 mb-6">Adherence Rate (%)</h3>
          {adherenceData.length > 0 ? (
            <ResponsiveContainer width="100%" height="80%">
              <BarChart data={adherenceData} layout="vertical" margin={{ left: 20 }}>
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                <Tooltip />
                <Bar dataKey="rate" radius={[0, 4, 4, 0]} barSize={20}>
                  {adherenceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.rate > 80 ? '#22c55e' : entry.rate > 50 ? '#eab308' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
             <p className="text-center text-gray-400 mt-10">No data to display for this filter.</p>
          )}
        </div>
      )}
    </div>
  );
};