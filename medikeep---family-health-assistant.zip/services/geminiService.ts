import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const parsePrescription = async (base64Image: string): Promise<any> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image
            }
          },
          {
            text: "Analyze this prescription image. Extract the medicine name, dosage instructions (frequency), and any special notes. Return a JSON object."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            medicineName: { type: Type.STRING },
            frequency: { type: Type.STRING },
            description: { type: Type.STRING },
            suggestedStock: { type: Type.NUMBER }
          }
        }
      }
    });
    
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Error parsing prescription:", error);
    return null;
  }
};

export const analyzeSymptoms = async (symptoms: string, medications: string[]): Promise<string> => {
  try {
    const medList = medications.join(', ');
    const prompt = `
      The patient is currently taking these medications: ${medList}.
      The patient reported the following symptoms: "${symptoms}".
      
      Please provide a brief, friendly analysis. 
      1. Could these symptoms be side effects of the medications?
      2. Is this potentially urgent (add a disclaimer)?
      Keep it under 100 words.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Could not analyze symptoms at this time.";
  } catch (error) {
    console.error("Error analyzing symptoms:", error);
    return "Error connecting to AI service.";
  }
};